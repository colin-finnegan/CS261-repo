/*
 * CS 261 PA1: Mini-ELF header verifier
 *
 * Name:     WRITE    YOUR    NAME    HERE ( or risk losing points )
 */

//   BRING YOUR OWN  p1-check.c   code  from PA-01 here