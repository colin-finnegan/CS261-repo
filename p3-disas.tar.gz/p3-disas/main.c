/*
 * CS 261 PA3: Mini-ELF disassembler Main driver
 *
 * Name:     WRITE    YOUR    NAME    HERE ( or risk losing points )
 */

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "p1-check.h"
#include "p2-load.h"
#include "p3-disas.h"

int main (int argc, char **argv)
{

    // Build starting from your PA-02 main.c and up
    
    return EXIT_SUCCESS;
}

