/*
 * CS 261 PA2: Mini-ELF loader
 *
 * Name: WRITE  YOUR FULL NAME HERE ( or risk losing points )
 */

//   BRING YOUR OWN  p2-load.c   code  from PA-02 here