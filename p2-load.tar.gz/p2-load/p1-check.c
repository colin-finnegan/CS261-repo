/*
 * CS 261 PA1: Mini-ELF header verifier
 *
 * Name:     MUST   WRITE    YOUR    NAME    HERE
 */

// Use your own p1.check.c code from PA1