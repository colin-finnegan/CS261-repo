/*
 *  CS 261 PA2: Mini-ELF loader Main driver
 *
 * Name:  WRITE  YOUR FULL NAME HERE
 */

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "p1-check.h"
#include "p2-load.h"

int main (int argc, char **argv)
{
    
    // Start from your main() of P1, thenmodify and add code as appropriate
    
    return EXIT_SUCCESS;
}

