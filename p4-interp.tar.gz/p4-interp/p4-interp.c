/*
 * CS 261 PA4: Mini-ELF interpreter
 *
 * Name: WRITE  YOUR  NAME  HERE
 */

#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "p4-interp.h"

//=======================================================================

void usage_p4 ()
{

}

//=======================================================================

bool parse_command_line_p4 
    (   int argc         , char **argv      ,
        bool *header     , bool *segments   , bool *membrief , 
        bool *memfull    , bool *disas_code , bool *disas_data ,
        bool *exec_normal, bool *exec_debug , char **file 
    )
{
    return true;
}

//=======================================================================

void dump_cpu( const y86_t *cpu ) 
{
    
}

//=======================================================================

y86_register_t decode_execute(  y86_t *cpu , bool *cond , const y86_inst_t *inst ,
                                y86_register_t *valA 
                             )
{
    y86_register_t valE = 0;
    return valE;
}

//=======================================================================

void memory_wb_pc(  y86_t *cpu , memory_t memory , bool cond , 
                    const y86_inst_t *inst , y86_register_t  valE , 
                    y86_register_t  valA 
                 )
{
    
}

